this whole folder (/examples/includes) is OPTIONAL to the class

it is being included only in support of /examples/example3.php which uses a jquery calendar widget

feel free to delete this directory if you don't want/need to use the calendar widget