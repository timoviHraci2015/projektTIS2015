<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<head>
	<title><?=$page_title?></title>
	<link href="stylesheet.css" rel="stylesheet" type="text/css">
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

<div style="margin-left:auto; margin-right:auto; width:80%; background-color: #ffffff;">
	<table border="0" align="center" cellpadding="0" cellspacing="0" style="width: 100%; background-color: #333333;">
	  <tr align="center" valign="middle" style="color: #fff;">
		<td colspan="2"><a href="events.php" class="menu">View/Create/Edit Events!</a></td>
		<td width="12%">&nbsp;</td>
		<td width="12%">&nbsp;</td>
		<td width="12%">&nbsp;</td>
		<td width="12%">&nbsp;</td>
		<td width="12%" align="right"></td>
	  </tr>
	</table>
</div>

<div style="margin: 0px auto 0px auto; width:80%; border: 1px solid #ccc; background-color: #ffffff;">
	<div style="padding: 2px 10px 10px 10px;">
