	</div>
</div>

<div style="margin-left:auto; margin-right:auto; width:80%; background-color: #ffffff;">
	<table border="0" align="center" cellpadding="0" cellspacing="0" style="width: 100%; background-color: #333333;">
	  <tr align="center" valign="middle">
		<td width="12%">Powered by <a href="http://ajaxcrud.com" class="menu">ajaxCRUD</a></td>
		<td width="12%">&nbsp;</td>
		<td width="12%">&nbsp;</td>
		<td width="12%">&nbsp;</td>
		<td width="12%">&nbsp;</td>
		<td width="12%">&nbsp;</td>
		<td width="12%">&nbsp;</td>
		<td width="12%">&copy; <a href="http://www.loudcanvas.com" class="menu">LCM</a></td>
	  </tr>
	</table>
</div>

</body>
</html>